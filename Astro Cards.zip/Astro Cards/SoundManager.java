import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.net.URL;

/**
 * The SoundManager class handles simple playback of audio files in the game.
 * It supports playing short sound effects like shooting or getting hit.
 * 
 * All methods are static, so this class does not require instantiation.
 *
 *
 * @author Erik Dhalla
 * @version 5/29/25
 */
public class SoundManager {

    /**
     * Plays a sound from the specified file path.
     * This method loads the sound and starts playback immediately.
     *
     * @param soundPath the file path to the audio file (e.g., "sounds/shoot.wav")
     */
    public static void playSound(String soundPath) {
        try {
            URL soundURL = SoundManager.class.getResource("/assets/sounds/" + soundPath);
            if (soundURL == null) {
                return;
            }

            AudioInputStream audioInput = 
                AudioSystem.getAudioInputStream(new File(soundPath));

            Clip clipObj = AudioSystem.getClip();
            clipObj.open(audioInput);
            clipObj.start();
        }
        catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }
}
