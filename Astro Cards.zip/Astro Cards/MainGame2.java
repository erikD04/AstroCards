import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.List;
import javax.swing.plaf.basic.BasicProgressBarUI;
import javax.sound.sampled.*;
import java.util.Arrays;
import java.net.URL;

/**
 * MainGame2 represents the primary game panel where all gameplay elements
 * are drawn and updated, including the player, enemies, bullets, flashcards,
 * collision detection, health management, score tracking, and more.
 * 
 * This panel runs on a Swing Timer and supports keyboard input.
 * Flashcards appear during gameplay to offer educational challenges,
 * rewarding health or score for correct answers.
 *
 * Key Features:
 * - Enemy spawning and bullet shooting
 * - Flashcard challenge system
 * - Player dodge and shield mechanics
 * - Sound effects and score system
 * - Game Over handling
 *
 * @author Erik Dhalla
 * @version 3/15/25
 */
public class MainGame2 extends JPanel implements ActionListener, KeyListener{

    /**
     * Thread that loads and displays a flashcard asynchronously. (Inner class)
     */
    private class FlashcardLoaderThread extends Thread {
        private String question;
        private String answer;

        public FlashcardLoaderThread(String question, String answer) {
            this.question = question;
            this.answer = answer;
        }

        public void run() {
            Flashcard card = new Flashcard(question, answer, MainGame2.this, player);  
            SwingUtilities.invokeLater(new FlashcardDisplayer(card));
        }
    }

    /**
     * Runnable class that displays a flashcard in the game panel. (Inner class)
     */
    public class FlashcardDisplayer implements Runnable {
        private Flashcard card;

        public FlashcardDisplayer(Flashcard card) {
            this.card = card;
        }

        @Override
        public void run() {
            add(card);
            card.revalidate();
        }
    }

    /**
     * Custom UI class for red square-styled health bar. (Inner class)
     */
    public class RedSquareHealthBarUI extends BasicProgressBarUI {
        @Override
        protected void paintDeterminate(Graphics g, JComponent component) {
            Graphics2D g2D = (Graphics2D) g;
            g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            super.paintDeterminate(g2D, component);
        }

        @Override
        protected Color getSelectionBackground() {
            return Color.WHITE;
        }

        @Override
        protected Color getSelectionForeground() {
            return Color.WHITE; 
        }
    }

    /**
     * Custom UI class for green square-styled dodge cooldown bar. (Inner class)
     */
    public class GreenSquareDodgeBarUI extends BasicProgressBarUI {
        @Override
        protected void paintDeterminate(Graphics g, JComponent component) {
            Graphics2D g2D = (Graphics2D) g;
            g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
            super.paintDeterminate(g2D, component);
        }

        @Override
        protected Color getSelectionBackground() {
            return Color.WHITE;
        }

        @Override
        protected Color getSelectionForeground() {
            return Color.WHITE; 
        }
    }

    /**
     * Delays the start of background music after the game begins. (Inner class)
     */
    private class DelayedMusicStarter implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            startMusicLoop();
        }
    }

    private final int PANEL_WIDTH = 512;
    private final int PANEL_HEIGHT = 512;

    // Sprite Sheets
    BufferedImage spriteSheet;
    BufferedImage backgroundSpriteSheet;
    BufferedImage projectileSpriteSheet;
    BufferedImage orangeTintedSprites;

    // Entity image arrays
    BufferedImage[] greenPlayerShips;
    BufferedImage[] tintedPlayer;
    BufferedImage[] enemyShips;
    BufferedImage[] tintedEnemies;
    BufferedImage[] playerBullets;

    // Space background image
    BufferedImage background;

    // GameObjects (Entities)
    GameObject player;
    ArrayList<GameObject> bulletArray;
    ArrayList<GameObject> enemyArray;
    ArrayList<GameObject> enemyBulletArray;
    
    // Enemy GameObject dimensions
    int[][] enemyDimensions;

    private Timer gameTimer;
    private Random randGen = new Random();

    // For flashcards
    int frameCount = 0;
    int nextFlashcardFrame = 1500;
    boolean isFlashcardActive = false;
    int lastFlashCardIndex;
    List<Flashcard> flashcardSet;

    // For player dodging
    long lastLeftPress = 0;
    long lastRightPress = 0;
    long lastDodgeTime = 0;
    boolean leftPressed = false;
    boolean rightPressed = false;
    private final int DODGE_COOLDOWN_MS = 3000;

    // For enemy spawning
    long lastEnemySpawnTime = 0;
    private final int ENEMY_SPAWN_COOLDOWN = 2000;

    // Health and dodge bars
    JProgressBar healthBar;
    JProgressBar dodgeBar;
    boolean isGameOver = false;

    // Score and highscore
    private int score;
    private int highScore;

    // For background sountracks
    private List<String> musicTracks = Arrays.asList(
        "/assets/Mercury.wav", 
        "/assets/Mars.wav", 
        "/assets/Venus.wav");
    private int currentTrackIndex = 0;
    private boolean isMusicPlaying = false;
    private Clip currentMusicClip;

    /**
     * Constructs the main game panel and initializes sprites, UI components,
     * timers, listeners, and flashcard mechanics.
     *
     * @param flashcards the list of flashcards to use during gameplay
     */
    public MainGame2(List<Flashcard> flashcards) {
        this.setSize(PANEL_WIDTH, PANEL_HEIGHT);
        this.setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
        this.setLayout(null);
        this.addKeyListener(this);
        this.setFocusable(true);
        this.requestFocusInWindow();

        flashcardSet = flashcards;
        score = 0;
        highScore = loadPreviousScore();

        try {
            spriteSheet = ImageIO.read(getClass().getResourceAsStream("/assets/SpaceShooterAssetPack_Ships.png"));

            backgroundSpriteSheet = 
            ImageIO.read(getClass().getResourceAsStream("/assets/SpaceShooterAssetPack_BackGrounds.png"));

            projectileSpriteSheet = 
            ImageIO.read(getClass().getResourceAsStream("/assets/SpaceShooterAssetPack_Projectiles.png"));

            orangeTintedSprites = ImageIO.read(getClass().getResourceAsStream("/assets/spaceshipsOrangeTint.png"));
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }

        enemyShips = new BufferedImage[] {spriteSheet.getSubimage(57, 18, 5, 6), 
            spriteSheet.getSubimage(49, 10, 5, 5),  
            spriteSheet.getSubimage(57, 25, 5, 6)};

        tintedEnemies = new BufferedImage[] {orangeTintedSprites.getSubimage(57, 18, 5, 6), 
            orangeTintedSprites.getSubimage(49, 10, 5, 5),  
            orangeTintedSprites.getSubimage(57, 25, 5, 6)};

        greenPlayerShips = new BufferedImage[] {spriteSheet.getSubimage(0, 16, 6, 8), 
            spriteSheet.getSubimage(8, 16, 8, 8), 
            spriteSheet.getSubimage(18, 16, 6, 8)};

        tintedPlayer = new BufferedImage[] {orangeTintedSprites.getSubimage(0, 16, 6, 8), 
            orangeTintedSprites.getSubimage(8, 16, 8, 8), 
            orangeTintedSprites.getSubimage(18, 16, 6, 8)};

        playerBullets = new BufferedImage[] {
            projectileSpriteSheet.getSubimage(4, 4, 1, 1), 
            projectileSpriteSheet.getSubimage(11, 4, 1, 2), 
            projectileSpriteSheet.getSubimage(19, 3, 1, 3),
            projectileSpriteSheet.getSubimage(27, 3, 1, 3)};

        background = backgroundSpriteSheet.getSubimage(0, 0, 128, 256);
        player = new GameObject(PANEL_WIDTH/2, 400, 0, 0, 8*6, 8*6, greenPlayerShips[1], 20);
        player.setNormalSprite(greenPlayerShips[1]);
        player.setFlashSprite(tintedPlayer[1]);
        player.setMaxHealth(20);

        bulletArray = new ArrayList<GameObject>();
        enemyArray = new ArrayList<GameObject>();
        enemyBulletArray = new ArrayList<GameObject>();
        enemyDimensions = new int[][] { {5 * 6, 6*6}, {5*6, 5*6}, {5*6, 6*6} };

        healthBar = new JProgressBar(0, 20);
        healthBar.setValue(20);
        healthBar.setStringPainted(true);

        healthBar.setForeground(Color.RED);
        healthBar.setBackground(Color.DARK_GRAY);
        healthBar.setFont(new Font("Arial", Font.BOLD, 12));
        healthBar.setBounds(18, 450, 120, 20);
        healthBar.setUI(new RedSquareHealthBarUI());

        healthBar.setVisible(true);
        this.add(healthBar);

        dodgeBar = new JProgressBar(0, DODGE_COOLDOWN_MS);
        dodgeBar.setValue(DODGE_COOLDOWN_MS);
        dodgeBar.setStringPainted(true);
        dodgeBar.setForeground(Color.GREEN);
        dodgeBar.setBackground(Color.DARK_GRAY);
        dodgeBar.setFont(new Font("Arial", Font.BOLD, 12));
        dodgeBar.setBounds(18, 420, 120, 20);
        dodgeBar.setUI(new GreenSquareDodgeBarUI());

        dodgeBar.setVisible(true);
        this.add(dodgeBar);

        gameTimer = new Timer(10, this);
        gameTimer.start();

        Timer delayStartMusic = new Timer(1500, new DelayedMusicStarter());
        delayStartMusic.setRepeats(false); 
        delayStartMusic.start();
    }

    /**
     * Called every 10ms by the game timer. Updates the game state,
     * handles flashcard timing, player updates, enemy and bullet movement,
     * health and dodge bar updates, and game-over logic.
     * 
     * @param e the timer event triggering this update
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        frameCount++;

        long currentTime = System.currentTimeMillis();
        int elapsed = (int) (currentTime - lastDodgeTime);
        int clampedElapsed = Math.min(elapsed, DODGE_COOLDOWN_MS);
        dodgeBar.setValue(clampedElapsed);

        if (!isFlashcardActive) {
            player.update();
            spawnEnemies();
            enemyMovement();
            shootBullets();
            updateHealthBar();
        } else {
            if (frameCount % 3 == 0) {
                enemyMovement();
                shootBullets(); 
            }
        }

        if (clampedElapsed >= DODGE_COOLDOWN_MS) {
            dodgeBar.setString("Dodge Ready");
        } else {
            dodgeBar.setString("");
        }

        repaint();

        if (frameCount >= nextFlashcardFrame && !isFlashcardActive) {
            isFlashcardActive = true;
            showFlashcardPrompt();
        } 

        if (player.getHealth() <= 0) {
            flashcardClosed();
            isGameOver = true;

            if (currentMusicClip != null && currentMusicClip.isRunning()) {
                currentMusicClip.stop();
                currentMusicClip.close();
            }

            healthBar.setString(0 + " / " + player.getMaxHealth());
            saveScoreToFile(score);
            int previousScore = loadPreviousScore();
            gameTimer.stop();
        }
    }

    /**
     * Draws all visual elements to the screen, including the background,
     * player, enemies, bullets, health/dodge bars, score, and game-over text.
     * 
     * @param g the graphics context used for painting
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D gObject = (Graphics2D) g;

        gObject.drawImage(background, 0, 0, 128*2, 256*2, null);
        gObject.drawImage(background, 256, 0, 128*2, 256*2, null);
        player.draw(gObject);

        for (int i = 0; i < enemyArray.size(); i++) {
            GameObject currentEnemy = enemyArray.get(i);

            if (currentEnemy.alive == true) {
                currentEnemy.draw(gObject);
            }
        }

        for (int i = 0; i < bulletArray.size(); i++) {
            GameObject currentBullet = bulletArray.get(i);

            if (!currentBullet.used) {
                currentBullet.draw(gObject);
            }
        }

        for (int i = 0; i < enemyBulletArray.size(); i++) {
            GameObject currentBullet = enemyBulletArray.get(i);

            if (!currentBullet.used) {
                currentBullet.draw(gObject);
            }
        }

        if (isGameOver) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.RED);
            g2d.setFont(new Font("SansSerif", Font.BOLD, 48));

            // For Game Over
            String message = "Game Over";
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(message);
            int textHeight = fm.getAscent();
            int centerX = (getWidth() - textWidth) / 2;
            int centerY = (getHeight() + textHeight) / 2;
            g2d.drawString(message, centerX, centerY);

            // For scores
            int previousScore = loadPreviousScore();
            int highScore = Math.max(previousScore, score);

            g2d.setFont(new Font("SansSerif", Font.BOLD, 20));
            g2d.setColor(Color.WHITE);
            String scoreText = "Your Score: " + score + "   |   High Score: " + highScore;
            FontMetrics scoreFm = g2d.getFontMetrics();
            int scoreTextWidth = scoreFm.stringWidth(scoreText);
            int scoreX = (getWidth() - scoreTextWidth) / 2;
            int scoreY = centerY + 40;

            g2d.drawString(scoreText, scoreX, scoreY);
        }

        if (!isGameOver) {
            gObject.setColor(Color.WHITE);
            g.setFont(new Font("SansSerif", Font.BOLD, 18));
            g.drawString("Score: " + score, 10, 30);
            g.drawString("High Score: " + highScore, 10, 50);
        }
    }

    /**
     * Handles player input such as left/right movement and shooting bullets.
     * Also manages double-tap dodge and starts sound effects on firing.
     * 
     * @param e the key event
     */
    @Override
    public void keyPressed(KeyEvent e) {
        long currentTime = System.currentTimeMillis();

        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            if (!leftPressed) {
                if (currentTime - lastLeftPress < 200 && 
                currentTime - lastDodgeTime > 1000) {
                    player.setXVelocity(-16);
                    lastDodgeTime = currentTime;
                } else {
                    player.setXVelocity(-3);
                }

                lastLeftPress = currentTime;
                leftPressed = true;
                setPlayerSprite(0);
            }
        }

        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            if (!rightPressed) {

                if (currentTime - lastRightPress < 200 && 
                currentTime - lastDodgeTime > 1000) {
                    player.setXVelocity(16); 
                    lastDodgeTime = currentTime;
                } else {
                    player.setXVelocity(3);
                }

                lastRightPress = currentTime;
                rightPressed = true;
                setPlayerSprite(2);
            }
        }

        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            int newShotID = randGen.nextInt(1000000);

            GameObject bulletL = new GameObject(player.getLeftEdge() + 6, 
                    player.getTopEdge() - 12, 0, -2, 1*6, 3*6, playerBullets[2], 0);

            GameObject bulletR = new GameObject(player.getRightEdge() - 12, 
                    player.getTopEdge() - 12, 0, -2, 1*6, 3*6, playerBullets[2], 0);

            bulletL.setShotID(newShotID);
            bulletR.setShotID(newShotID);

            bulletArray.add(bulletL);
            bulletArray.add(bulletR);
            SoundManager.playSound("BulletFire3.wav");
        }
    }

    /**
     * Updates the sprite image of the player to match the specified index
     * (used for directional movement and hit flash effect).
     * 
     * @param index the index of the sprite to set
     */
    public void setPlayerSprite(int index) {
        player.setImage(greenPlayerShips[index]); 
        player.setNormalSprite(greenPlayerShips[index]); 
        player.setFlashSprite(tintedPlayer[index]); 
    }

    /**
     * Updates the player's health bar based on current health.
     * Also brings the health bar to the front of the UI.
     */
    public void updateHealthBar() {
        healthBar.setValue(player.getHealth());
        healthBar.setStringPainted(true);
        healthBar.setString(player.getHealth() + " / " + player.getMaxHealth());
        this.setComponentZOrder(healthBar, 0);
        this.revalidate();
        this.repaint();
    }

    /**
     * Resets flags and velocity when the player releases movement keys.
     * 
     * @param e the key event
     */
    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            leftPressed = false;

            player.setXVelocity(0);
            setPlayerSprite(1);
        } 

        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            rightPressed = false;

            player.setXVelocity(0);
            setPlayerSprite(1);
        }
    }

    /**
     * Spawns a new enemy at random intervals, ensuring no overlap
     * with existing enemies.
     */
    public void spawnEnemies() {
        long currentTime = System.currentTimeMillis();

        if (currentTime - lastEnemySpawnTime < ENEMY_SPAWN_COOLDOWN) {
            return;
        }

        lastEnemySpawnTime = currentTime;
        int spriteIndex = randGen.nextInt(enemyShips.length); 
        BufferedImage sprite = enemyShips[spriteIndex];

        int width = enemyDimensions[spriteIndex][0];
        int height = enemyDimensions[spriteIndex][1];

        int x = randGen.nextInt(PANEL_WIDTH - width);
        int y = height * -1;

        GameObject newEnemy = new GameObject(x, y, 0, 1, width, height, sprite, 3);
        newEnemy.setNormalSprite(sprite);
        newEnemy.setFlashSprite(tintedEnemies[spriteIndex]);

        boolean overlapping = false;
        for (int i = 0; i < enemyArray.size(); i++) {
            GameObject current = enemyArray.get(i);

            if ((Math.abs(current.getLeftEdge() - newEnemy.getLeftEdge()) 
                < newEnemy.getWidth()) &&
            Math.abs(current.getTopEdge() - newEnemy.getTopEdge()) 
            < newEnemy.getHeight()) {
                overlapping = true;
                break;
            }
        }

        if (!overlapping) {
            enemyArray.add(newEnemy);
        }

        while ( (!enemyArray.isEmpty()) && 
        ( (!enemyArray.get(0).alive) || enemyArray.get(0).getTopEdge() > 
            PANEL_HEIGHT + enemyArray.get(0).getHeight()) ) {
            enemyArray.remove(0);
        }
    }

    /**
     * Updates enemy movement, handles collisions with the player,
     * spawns bullets for each enemy, and updates enemy bullets.
     */
    public void enemyMovement() {
        for (int i = 0; i < enemyArray.size(); i++) {
            GameObject currentEnemy = enemyArray.get(i);
            currentEnemy.update();

            if (currentEnemy.isColliding(player)) {
                currentEnemy.alive = false;
                player.subtractHealth(2);
                player.markHit();
                SoundManager.playSound("Hit.wav");
                enemyArray.remove(i);
                addScore(-5);
            }

            spawnBullets(enemyArray.get(i));
        }

        for (int i = 0; i < enemyBulletArray.size(); i++) {
            GameObject currentBullet = enemyBulletArray.get(i);
            currentBullet.update();

            if (!currentBullet.used && player.alive && 
            currentBullet.isColliding(player)) {
                currentBullet.used = true;
                player.subtractHealth(1);
                player.markHit();
                SoundManager.playSound("Hit.wav");
                addScore(-1);
            }
        }

        while ( (!enemyBulletArray.isEmpty()) && 
        (enemyBulletArray.get(0).used || enemyBulletArray.get(0).getBottomEdge() > 
            PANEL_HEIGHT)) {
            enemyBulletArray.remove(0);
        }
    }

    /**
     * Spawns a bullet from an enemy object at regular intervals.
     * 
     * @param enemy the GameObject enemy that shoots
     */
    public void spawnBullets(GameObject enemy) {
        long currentTime = System.currentTimeMillis();

        int bulletWidth = playerBullets[0].getWidth() * 6;
        int bulletHeight = playerBullets[1].getHeight() * 6;

        int bulletX = enemy.getLeftEdge() + (enemy.getWidth() / 2) - (bulletWidth / 2);
        int bulletY = enemy.getBottomEdge();
        if (currentTime - enemy.getLastShotTime() > 3000) {
            GameObject enemyBullet = new GameObject(
                    bulletX, bulletY, 0, 2, 
                    bulletWidth, bulletHeight, playerBullets[1], 0);

            enemyBulletArray.add(enemyBullet);
            enemy.setLastShotTime(currentTime);
        }
    }

    /**
     * Updates player bullets and checks for collisions with enemies.
     * Removes bullets that are off-screen or used.
     */
    public void shootBullets() {
        for (int i = 0; i < bulletArray.size(); i++) {
            GameObject currentBullet = bulletArray.get(i);
            currentBullet.update();

            for (int j = 0; j < enemyArray.size(); j++) {
                GameObject currentEnemy = enemyArray.get(j);

                if (!currentBullet.used && currentEnemy.alive && 
                currentBullet.isColliding(currentEnemy)) {
                    int hitShotID = currentBullet.getShotID();

                    for (int k = 0; k < bulletArray.size(); k++) {
                        if (bulletArray.get(k).getShotID() == hitShotID) {
                            bulletArray.get(k).used = true;
                        }
                    }

                    currentEnemy.subtractHealth(1);
                    currentEnemy.markHit();
                    SoundManager.playSound("Hit.wav");

                    if (currentEnemy.getHealth() <=0) {
                        currentEnemy.alive = false;
                        addScore(5);
                    }

                    break;
                }
            }
        }

        while ( (!bulletArray.isEmpty()) && 
        (bulletArray.get(0).used || bulletArray.get(0).getTopEdge() < 0)) {
            bulletArray.remove(0);
        }
    }

    /**
     * Loads and displays a flashcard by spawning a new thread.
     * 
     * @param question the flashcard question text
     * @param answer the flashcard answer text
     */
    public void displayFlashcard(String question, String answer) {
        new FlashcardLoaderThread(question, answer).start();
    }

    /**
     * Randomly selects and displays a new flashcard prompt,
     * ensuring it's not the same as the previous one.
     */
    public void showFlashcardPrompt() {
        if (flashcardSet == null || flashcardSet.isEmpty()) {
            return;
        }

        int index;
        do {
            index = randGen.nextInt(flashcardSet.size());
        } while (flashcardSet.size() > 1 && index == lastFlashCardIndex);

        lastFlashCardIndex = index;
        Flashcard card = flashcardSet.get(index);
        displayFlashcard(card.getQuestion(), card.getAnswer());
    }

    /**
     * Called when a flashcard is removed from the screen.
     * Resets the isFlashcardActive flag and schedules the next flashcard.
     */
    public void flashcardClosed() {
        isFlashcardActive = false;
        nextFlashcardFrame = frameCount + randGen.nextInt(500) + 1500;
    }

    /**
     * Adds to the player's score while ensuring it doesn't drop below zero.
     * 
     * @param addAmount the score to add (can be negative)
     */
    public void addScore(int addAmount) {
        score = Math.max(score + addAmount, 0);
    }

    /**
     * Saves the current score to a file named "score.txt".
     * 
     * @param score the score to save
     */
    public void saveScoreToFile(int score) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("score.txt"))) {
            writer.write(String.valueOf(score));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Loads the most recently saved score from "score.txt".
     * 
     * @return the previously saved score, or 0 if file not found
     */
    public int loadPreviousScore() {
        File file = new File("score.txt");
        if (!file.exists()) {
            return 0;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            return Integer.parseInt(reader.readLine());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * Starts looping background music. Waits 5 seconds between tracks.
     * Music stops when the game is over.
     */
    public void startMusicLoop() {
        Thread musicThread = new Thread(() -> {
            while (!isGameOver) {
                try {
                    String path = musicTracks.get(currentTrackIndex);
                    URL soundURL = getClass().getResource(path);
                    
                    if (soundURL == null) {
                        System.err.println("Could not find music file: " + path);
                        return;
                    }
                    
                    AudioInputStream audioStream = AudioSystem.getAudioInputStream(soundURL);
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioStream);
                    currentMusicClip = clip;
                    clip.start();
                    
                    // Wait for the clip to actually start
                    while (!clip.isRunning()) {
                        Thread.sleep(10);
                    }
                    
                    // Wait until the clip finishes
                    while (clip.isRunning()) {
                        Thread.sleep(200);
                    }
                    
                    clip.stop();
                    clip.close();
                    currentTrackIndex = (currentTrackIndex + 1) % musicTracks.size();

                    int delay = 5000;
                    int waited = 0;
                    while (waited < delay && !isGameOver) {
                        Thread.sleep(200);
                        waited += 200;
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        musicThread.setDaemon(true);
        musicThread.start();
    }

    /**
     * Returns a reference to the player GameObject.
     * 
     * @return the player GameObject
     */
    public GameObject getPlayer() {
        return player;
    }

    /**
     * Unused keyTyped method (required by KeyListener interface).
     */
    @Override
    public void keyTyped(KeyEvent e) {}
}