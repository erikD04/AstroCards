import java.awt.*;
import javax.swing.*;
import java.util.List;

/**
 * Represents the main game window for the Astro Cards game.
 * Initializes the frame, displays the flashcard setup screen first,
 * and transitions to the game panel once the player starts the game.
 *
 * This class acts as the outer frame container that holds either
 * the setup screen or the main game content.
 *
 * @author Erik Dhalla
 * @version 3/15/25
 */
public class GameFrame2 extends JFrame {
    MainGame2 myGame;
    private FlashcardSetupScreen setupScreen;

    /**
     * Constructs the main window, sets window properties,
     * and adds the flashcard setup screen on launch.
     */
    public GameFrame2() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();

        this.setSize(512, 512);
        this.setResizable(false);
        this.setLayout(null);
        this.setLocationRelativeTo(null);

        // Starts with flashcard setup screen
        setupScreen = new FlashcardSetupScreen(this, myGame);
        this.add(setupScreen);
        this.setTitle("Astro Cards");
        this.setVisible(true);
    }

    /**
     * Starts the main game using the given flashcards. Replaces the
     * setup screen with the MainGame2 panel and triggers background sound.
     * 
     * @param flashcards the list of flashcards to load into the game
     */
    public void startGame(List<Flashcard> flashcards) {
        this.getContentPane().removeAll();
        myGame = new MainGame2(flashcards);
        GameObject player = myGame.getPlayer();
        setupScreen.setPlayer(player);

        this.add(myGame); 
        this.revalidate();
        myGame.requestFocusInWindow();
        SoundManager.playSound("Warp Jingle.wav");
    }

    /**
     * Main method to launch the game application.
     * Creates and displays the GameFrame2 window.
     * 
     * @param args unused command-line arguments
     */
    public static void main(String[] args) {
        GameFrame2 newGame = new GameFrame2();
    }
}
