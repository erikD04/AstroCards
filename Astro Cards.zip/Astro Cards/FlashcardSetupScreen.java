import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.Color;
import java.io.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.List;

/**
 * A setup screen panel where users can add, load, or reset flashcards
 * before starting the game. Supports UI controls for file selection,
 * text input for questions/answers, and launching the game with loaded data.
 *
 * This class manages user interaction before the main game screen loads.
 *
 * @author Erik Dhalla
 * @version 5/27/25
 */
public class FlashcardSetupScreen extends JPanel {
    
    /**
     * Action listener for the "Create New" button. Saves the flashcard
     * to the manager and clears the input fields. (Inner class)
     */
    private class CreateNewButtonListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            showFlashcardInputForm();
        }
    }

    /**
     * Action listener for the "Start Game" button. Attempts to save
     * the last flashcard and launches the main game if valid. (Inner class)
     */
    private class LoadExistingButtonListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser chooser = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
            chooser.setFileFilter(filter);

            int result = chooser.showOpenDialog(FlashcardSetupScreen.this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = chooser.getSelectedFile();

                if (FlashcardManager.isValidFlashcardFile(selectedFile)) {
                    flashcardManager.setFlashcardFile(selectedFile);
                    try {
                        flashcards = FlashcardManager.loadFromFile(
                            selectedFile.getAbsolutePath(), mainGame, player);
                        mainFrame.startGame(flashcards);
                    } catch (IOException ioe) {
                        ioe.printStackTrace();
                    }
                } else {
                    Component parentComponent = FlashcardSetupScreen.this;
                    String message = "Invalid file format. Please choose another file or create a new flashcard set.";
                    String title = "Invalid File";
                    int messageType = JOptionPane.ERROR_MESSAGE;

                    JOptionPane.showMessageDialog(parentComponent, message, title, messageType);
                }
            }
        }
    }

    /**
     * Action listener for the "Add Flashcard" button. Adds the current flashcard
     * input fields to the flashcard manager if valid.
     */
    private class AddFlashcardListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String q = questionField.getText().trim();
            String a = answerField.getText().trim();
           
            if(!q.isEmpty() && !a.isEmpty()) {
                flashcardManager.addFlashcard(q, a);
                questionField.setText("");
                answerField.setText("");
            }
        }
    }

    /**
     * Action listener for the "Start Game" button. Saves flashcards and starts the 
     * game only if there are at least 3 flashcards.
     */
    private class StartGameListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (flashcardManager.getFlashcards().size() < 3) {
                Component parentComponent = FlashcardSetupScreen.this;
                String message = "Please add at least 3 flashcards before starting the game.";
                String title = "Not Enough Flashcards";
                int messageType = JOptionPane.WARNING_MESSAGE;

                JOptionPane.showMessageDialog(parentComponent, message, title,
                    messageType);
                return;
            }

            try {
                flashcardManager.saveToFile("flashcards.txt");
                List<Flashcard> flashcards = flashcardManager.getFlashcards();
                mainFrame.startGame(flashcards);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Runnable to display the "Start Game" button after layout update.
     */
    public class StartGameDisplayer implements Runnable {
        @Override
        public void run() {
            mainFrame.getContentPane().add(startGameButton);
            mainFrame.revalidate();
            mainFrame.repaint();
        }
    }
    public final static int FLASHCARD_WIDTH = 428;
    public final static int FLASHCARD_HEIGHT = 180;

    private int flashcardX = (512 - FLASHCARD_WIDTH) / 2;
    private int flashcardY = 48;

    private JButton createNewButton;
    private JButton loadExistingButton;

    private FlashcardManager flashcardManager;
    private JTextArea questionField;
    private JTextArea answerField;
    private JButton addButton;
    private JButton startGameButton;

    private GameFrame2 mainFrame;
    private MainGame2 mainGame;
    private GameObject player;

    List<Flashcard> flashcards;

    /**
     * Constructs the setup screen with reference to the main frame and game.
     *
     * @param mainFrame the game window
     * @param mainGame the main game panel
     */
    public FlashcardSetupScreen(GameFrame2 mainFrame, MainGame2 mainGame) {
        this.mainFrame = mainFrame;
        this.mainGame = mainGame;
        flashcardManager = new FlashcardManager(mainGame);

        createNewButton = new JButton("Create New Flashcards");
        createNewButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        loadExistingButton = new JButton("Load Existing Flashcards");
        loadExistingButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        createNewButton.addActionListener(new CreateNewButtonListener());
        loadExistingButton.addActionListener(new LoadExistingButtonListener());

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.LIGHT_GRAY);
        setBounds(flashcardX, flashcardY, 428, 180);

        questionField = new JTextArea(2, 28);
        questionField.setFont(new Font("SansSerif", Font.BOLD, 14));
        questionField.setMaximumSize(questionField.getPreferredSize());
        questionField.setAlignmentX(Component.CENTER_ALIGNMENT);
        questionField.setLineWrap(true); 
        questionField.setWrapStyleWord(true);

        answerField = new JTextArea(2, 28);
        answerField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        answerField.setMaximumSize(answerField.getPreferredSize());
        answerField.setAlignmentX(Component.CENTER_ALIGNMENT);
        answerField.setLineWrap(true); 
        answerField.setWrapStyleWord(true); 

        addButton = new JButton("Add Flashcard");
        addButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        startGameButton = new JButton("Start Game");
        startGameButton.setBounds(181, 432, 150, 30);
        startGameButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createVerticalStrut(30));
        add(createNewButton);
        add(Box.createVerticalStrut(20));
        add(loadExistingButton);
        add(Box.createVerticalStrut(30));

        addButton.addActionListener(new AddFlashcardListener());
        startGameButton.addActionListener(new StartGameListener());
    }

    /**
     * Displays the flashcard input form where users can enter questions and answers.
     */
    public void showFlashcardInputForm() {
        loadExistingButton.setVisible(false);
        createNewButton.setVisible(false);
        this.removeAll();
        this.revalidate();

        JPanel questionRow = new JPanel();
        questionRow.setLayout(new BoxLayout(questionRow, BoxLayout.X_AXIS));
        questionRow.setOpaque(false);

        add(Box.createVerticalStrut(30));
        questionRow.setOpaque(false);
        questionRow.add(Box.createHorizontalStrut(10));
        questionRow.add(new JLabel("Question:"));
        questionRow.add(Box.createHorizontalStrut(10));
        questionRow.add(questionField);
        questionRow.add(Box.createHorizontalStrut(10));

        add(questionRow);
        add(Box.createVerticalGlue());

        JPanel inputRow = new JPanel();
        inputRow.setLayout(new BoxLayout(inputRow, BoxLayout.X_AXIS));
        inputRow.setOpaque(false);

        inputRow.add(Box.createHorizontalStrut(10));
        inputRow.add(new JLabel("Answer:"));
        inputRow.add(Box.createHorizontalStrut(10));
        inputRow.add(answerField); 
        inputRow.add(Box.createHorizontalStrut(10));
        add(inputRow);

        add(Box.createVerticalGlue());
        add(addButton);
        add(Box.createHorizontalStrut(10));

        mainFrame.add(Box.createVerticalGlue());
        SwingUtilities.invokeLater(new StartGameDisplayer());

        this.revalidate();
        this.repaint();
    }

    /**
     * Sets the player instance and forwards it to the flashcard manager.
     *
     * @param player the player object
     */
    public void setPlayer(GameObject player) {
        this.player = player;
        flashcardManager.setPlayer(player);
    }
}
