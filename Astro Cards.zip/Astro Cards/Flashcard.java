import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/**
 * A Flashcard panel that displays a question and accepts user input.
 * If the user answers correctly, it triggers game rewards such as healing and score.
 * Incorrect answers briefly show feedback before resetting the question.
 *
 * This class is responsible for:
 * - Displaying a flashcard with a question and answer field
 * - Handling correct/incorrect logic
 * - Rewarding the player (via health and score)
 * - Automatically removing itself after a delay
 *
 * @author: Erik Dhalla
 * @version: 4/24/25
 */
public class Flashcard extends JPanel implements ActionListener {

    /**
     * Timer action that restores the original question after showing incorrect 
     * feedback. (Inner class)
     */
    private class RestoreQuestionTimer implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            questionLabel.setText("<html><div style='text-align:center; width:325px;'>" + rawQuestionText + "</div></html>");
        }
    }

    /**
     * Handles answer submission via ENTER key or button press. Rewards player on 
     * correct response, resets question on incorrect. (Inner class)
     */
    private class SubmitAnswerAction extends AbstractAction{
        @Override
        public void actionPerformed(ActionEvent e) {
            String userAnswer = answerField.getText().trim();

            if (userAnswer.equalsIgnoreCase(correctAnswer)) {
                questionLabel.setText("<html><div style='text-align:center; width:325px; color:green;'>Correct!<br>You get +2 Health!<br>+10 Score!</div></html>");
                player.addHealth(2);
                mainGame.addScore(10);
                startRemoveFlashcardTimer();
            } else {
                questionLabel.setText("<html><div style='text-align:center; width:325px; color:red;'>Incorrect, please try again!</div></html>");

                Timer restoreTimer = new Timer(500, new RestoreQuestionTimer());
                restoreTimer.setRepeats(false); 
                restoreTimer.start();
            }
        }
    }

    /**
     * Handles flashcard removal from the game panel after correct answer. 
     * (Inner class)
     */
    private class removeCard implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Container parent = Flashcard.this.getParent();
            if (parent != null) {
                parent.remove(Flashcard.this);
                parent.revalidate(); 
            }

            mainGame.flashcardClosed();
        }
    }

    // Instance variables
    private MainGame2 mainGame;
    private JLabel questionLabel;
    private JTextArea answerField;
    private JButton submitButton;
    private String correctAnswer;
    private String rawQuestionText;
    private GameObject player;

    public final static int FLASHCARD_WIDTH = 428;
    public final static int FLASHCARD_HEIGHT = 180;

    private int flashcardX = (512 - FLASHCARD_WIDTH) / 2;
    private int flashcardY = 58;

    /**
     * Constructs a Flashcard panel.
     *
     * @param question  The question to display.
     * @param answer    The correct answer.
     * @param mainGame  Reference to the main game for triggering events.
     * @param player    The player object to apply health changes.
     */
    public Flashcard(String question, String answer, MainGame2 mainGame, GameObject player) {
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setBackground(Color.LIGHT_GRAY);
        this.setBounds(flashcardX, flashcardY, FLASHCARD_WIDTH, FLASHCARD_HEIGHT);
        this.setOpaque(false);

        this.mainGame = mainGame;
        this.player = player;
        this.correctAnswer = answer;
        this.rawQuestionText = question;

        questionLabel = new JLabel("<html><div style='text-align:center; width:325px;'>"
            + question + "</div></html>");
        questionLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        questionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        answerField = new JTextArea(2, 26);
        answerField.setMaximumSize(answerField.getPreferredSize());
        answerField.setAlignmentX(Component.CENTER_ALIGNMENT);
        answerField.setLineWrap(true);
        answerField.setWrapStyleWord(true);
        answerField.setFont(new Font("SansSerif", Font.PLAIN, 14));

        InputMap input = answerField.getInputMap(JComponent.WHEN_FOCUSED);
        ActionMap action = answerField.getActionMap();

        input.put(KeyStroke.getKeyStroke("ENTER"), "submitAnswer");
        action.put("submitAnswer", new SubmitAnswerAction());

        this.add(Box.createVerticalStrut(30));
        this.add(questionLabel);
        this.add(Box.createVerticalGlue());

        JPanel inputRow = new JPanel();
        inputRow.setLayout(new BoxLayout(inputRow, BoxLayout.X_AXIS));
        inputRow.setOpaque(false);
        submitButton = new JButton("Submit");
        submitButton.addActionListener(this);

        inputRow.add(Box.createHorizontalStrut(10));
        inputRow.add(answerField);
        inputRow.add(Box.createHorizontalStrut(10));
        inputRow.add(submitButton);

        this.add(Box.createVerticalGlue());
        this.add(Box.createVerticalStrut(20));
        this.add(inputRow);

        this.setFocusable(true);
        this.requestFocusInWindow();
        this.setVisible(true);
    }

    /**
     * Custom rendering for the flashcard background.
     * 
     * @param g the graphics context used for painting
     */
    protected void paintComponent(Graphics g) {
        Graphics2D g2D = (Graphics2D) g.create();
        g2D.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.7f));
        g2D.setColor(new Color(200, 200, 200));
        g2D.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
        g2D.dispose();

        super.paintComponent(g);
    }

    /**
     * Handles submit button click events.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        new SubmitAnswerAction().actionPerformed(e);
    }

    /**
     * Starts the timer that removes the flashcard after correct answer.
     */
    private void startRemoveFlashcardTimer() {
        Timer removeTimer = new Timer(1500, new removeCard());
        removeTimer.setRepeats(false);
        removeTimer.start();
    }

    /**
     * Returns the current question text.
     * @return Question string
     */
    public String getQuestion() {
        return questionLabel.getText();
    }

    /**
     * Returns the correct answer.
     * @return Answer string
     */
    public String getAnswer() {
        return correctAnswer;
    }
}