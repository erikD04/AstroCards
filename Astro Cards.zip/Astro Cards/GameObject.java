import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Represents any object in the game with position, size, velocity,
 * image sprite, and health. Used for players, enemies, and bullets.
 * 
 * Supports collision detection, health tracking, and sprite switching
 * for hit feedback.
 * 
 * Each GameObject instance can be moved, drawn, and interacted with
 * using public methods.
 *
 * @author Erik Dhalla
 * @version 3/15/25
 */
public class GameObject {
    private int x;
    private int y;
    private int xVelocity;
    private int yVelocity;
    private int width;
    private int height;
    private BufferedImage img;

    private int shotID = -1;
    private int health;
    private int maxHealth;
    boolean alive = true; // For player or enemies
    boolean used = false; // For bullets

    private long lastEnemyShotTime = 0;

    private BufferedImage normalSprite;
    private BufferedImage flashSprite;

    private boolean recentlyHit = false;
    private long hitFlashStartTime = 0;
    private final long FLASH_DURATION = 150;

    /**
     * Constructs a GameObject with initial position, velocity, size, image, and 
     * health.
     * 
     * @param x the x-position of the object
     * @param y the y-position of the object
     * @param xVel the x-velocity of the object
     * @param yVel the y-velocity of the object
     * @param width the width of the object
     * @param height the height of the object
     * @param image the image to render for the object
     * @param health the starting health of the object
     */
    public GameObject(int x, int y, int xVelocity, int yVelocity, int width, int height, BufferedImage img, int health) {
        this.x = x;
        this.y = y;
        this.xVelocity = xVelocity;
        this.yVelocity = yVelocity;
        this.width = width;
        this.height = height;
        this.img = img;
        this.health = health;
        this.maxHealth = health;

        this.normalSprite = img;
    }
    
    /**
     * Updates the position based on current velocity. Also resets flash sprite after
     * a short duration.
     */
    public void update() {
        x += xVelocity;
        y += yVelocity;

        if (x < 0) {
            x = 0;
        }

        if (getRightEdge() > 512) {
            x = 512 - width;
        }

        if (recentlyHit && 
        System.currentTimeMillis() - hitFlashStartTime > FLASH_DURATION) {
            recentlyHit = false;
        }
    }

    /**
     * Draws the GameObject on the screen, using the flash sprite if recently hit.
     * 
     * @param g2D the Graphics2D context used to draw the object
     */
    public void draw(Graphics g) {
        if (!alive) {
            return;
        }

        Graphics2D gObject = (Graphics2D) g;
        BufferedImage spriteToDraw = img;

        if (recentlyHit) {
            // Difference of time between currrent point & last hitFlash
            long elapsed = System.currentTimeMillis() - hitFlashStartTime;

            if (elapsed < FLASH_DURATION) {
                if (flashSprite != null) {
                    spriteToDraw = flashSprite;
                }
            } else {
                recentlyHit = false;
                spriteToDraw = normalSprite;
                img = normalSprite;
            }
        }

        gObject.drawImage(spriteToDraw, x, y, width, height, null);
    }

    /**
     * Returns true if this GameObject collides with another GameObject.
     * 
     * @param other the other GameObject to check collision against
     * @return true if their bounds intersect, false otherwise
     */
    public boolean isColliding(GameObject other) {
        return (this.getLeftEdge() < other.getRightEdge()) && 
        (this.getRightEdge() > other.getLeftEdge()) && 
        (this.getTopEdge() < other.getBottomEdge()) && 
        (this.getBottomEdge() > other.getTopEdge());
    }

    /**
     * Temporarily switches the image to a tinted sprite for hit feedback.
     * 
     * @param tintedSprite the flash sprite image
     */
    public void flashTint(BufferedImage tintedSprite) {
        this.setImage(tintedSprite);
    }

    /**
     * Flags the object as recently hit to trigger flash effects.
     */
    public void markHit() {
        recentlyHit = true;
        hitFlashStartTime = System.currentTimeMillis();
    }

    /**
     * Returns the amount of time since the last enemy shot.
     *
     * @return the timestamp of the last shot fired
     */
    public long getLastShotTime() {
        return lastEnemyShotTime;
    }

    /**
     * Sets the time of the last shot fired.
     *
     * @param time the timestamp to set
     */
    public void setLastShotTime(long time) {
        lastEnemyShotTime = time;
    }

    /**
     * Sets the image used for rendering the object.
     *
     * @param img the new image to display
     */
    public void setImage(BufferedImage img) {
        this.img = img;
    }

    /**
     * Sets the sprite used when the object is in its normal state.
     *
     * @param img the image to use as the default sprite
     */
    public void setNormalSprite(BufferedImage img) {
        this.normalSprite = img;
    }

    /**
     * Sets the flash sprite to be used when the object is hit.
     *
     * @param img the image to use as the flash sprite
     */
    public void setFlashSprite(BufferedImage img) {
        this.flashSprite = img;
    }

    /**
     * Assigns an ID to this GameObject’s projectile (used for tracking bullets).
     *
     * @param id the identifier for this shot
     */
    public void setShotID(int id) {
        this.shotID = id;
    }

    /**
     * Returns the shot ID associated with this object.
     *
     * @return the shot ID
     */
    public int getShotID() {
        return shotID;
    }

    /**
     * Subtracts health from the object.
     *
     * @param amount the amount to subtract
     */
    public void subtractHealth(int subtractAmount) {
        health -= subtractAmount;
    }

    /**
     * Increases health by the specified amount up to the max health.
     *
     * @param addAmount the amount to add to health
     */
    public void addHealth(int addAmount) {
        health = Math.min(health + addAmount, maxHealth);
    }

    /**
     * Gets the current health value.
     *
     * @return the object's current health
     */
    public int getHealth() {
        return health;
    }

    /**
     * Sets the maximum health value.
     *
     * @param maxHealth the maximum health this object can have
     */
    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }

    /**
     * Gets the maximum health value.
     *
     * @return the max health value
     */
    public int getMaxHealth() {
        return maxHealth;
    }

    /**
     * Gets the current left edge x-position.
     *
     * @return the x-coordinate of the left edge
     */
    public int getLeftEdge() {
        return x;
    }

    /**
     * Gets the x-coordinate of the right edge.
     *
     * @return right edge position
     */
    public int getRightEdge() {
        return this.x + width;
    }

    /**
     * Gets the y-coordinate of the top edge.
     *
     * @return top edge position
     */
    public int getTopEdge() {
        return y;
    }

    /**
     * Gets the y-coordinate of the bottom edge.
     *
     * @return bottom edge position
     */
    public int getBottomEdge() {
        return this.y + height;
    }

    /**
     * Sets the x-velocity of the object.
     *
     * @param xVel velocity along the x-axis
     */
    public void setXVelocity(int xVel) {
        xVelocity = xVel;
    }

    /**
     * Gets the current x velocity.
     *
     * @return x-axis velocity
     */
    public int getXVelocity() {
        return xVelocity;
    }

    /**
     * Sets the y-velocity of the object.
     *
     * @param yVel velocity along the y-axis
     */
    public void setYVelocity(int yVel) {
        yVelocity = yVel;
    }

    /**
     * Gets the current y velocity.
     *
     * @return y-axis velocity
     */
    public int getYVelocity() {
        return yVelocity;
    }

    /**
     * Sets the width of the object.
     *
     * @param width the new width
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * Gets the width of the object.
     *
     * @return current width
     */
    public int getWidth() {
        return width;
    }

    /**
     * Sets the height of the object.
     *
     * @param height the new height
     */
    public void setHeight() {
        this.height = height;
    }

    /**
     * Gets the height of the object.
     *
     * @return current height
     */
    public int getHeight() {
        return height;
    }
}
