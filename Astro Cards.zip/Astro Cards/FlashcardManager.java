import java.util.*;
import java.io.*;

/**
 * Manages flashcard operations, including adding flashcards,
 * saving to and loading from files, and tracking flashcard data.
 * Can also validate file format and associate with a game instance.
 * 
 * This class serves as the controller for flashcard-related features.
 *
 * @author Erik Dhalla
 * @version 5/02/25
 */
public class FlashcardManager {
    private List<Flashcard> flashcardSet;
    private File flashcardFile;

    private MainGame2 mainGame;
    private GameObject player;

    /**
     * Constructs a FlashcardManager with the given game instance.
     * 
     * @param mainGame the main game instance to interact with
     */
    public FlashcardManager(MainGame2 mainGame) {
        flashcardSet = new ArrayList<>();    
        this.mainGame = mainGame;
    }

    /**
     * Sets the file used for saving or loading flashcards.
     *
     * @param file the File object to be stored internally
     */
    public void setFlashcardFile(File file) {
        flashcardFile = file;
    }

    /**
     * Gets the file currently associated with saving or loading flashcards.
     *
     * @return the currently set flashcard file
     */
    public File getFlashcardFile() {
        return flashcardFile;
    }

    /**
     * Adds a flashcard to the manager with the specified question and answer.
     * 
     * @param question the flashcard question
     * @param answer the corresponding flashcard answer
     */
    public void addFlashcard(String question, String answer) {
        flashcardSet.add(new Flashcard(question, answer, mainGame, this.player));
    }

    /**
     * Saves the flashcards to a text file with the given path.
     * 
     * @param filename the path to save the flashcards
     * @throws IOException if an error occurs during writing
     */
    public void saveToFile(String fileName) throws IOException {

        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        for (int i = 0; i < flashcardSet.size(); i++) {
            writer.write(flashcardSet.get(i).getQuestion() + "::" + flashcardSet.get(i).getAnswer());
            writer.newLine();
        }

        writer.close();
    }

    /**
     * Loads flashcards from the given file path, parsing each line as 
     * question::answer.
     * 
     * @param filename the path to load flashcards from
     * @param mainGame the game instance to bind to loaded flashcards
     * @param player the player object for game effects
     * @return list of loaded flashcards
     * @throws IOException if the file cannot be read
     */
    public static List<Flashcard> loadFromFile(String fileName, MainGame2 mainGame, GameObject player) throws IOException {
        List<Flashcard> list = new ArrayList<>(); 
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String currentLine;
        while ((currentLine = reader.readLine()) != null) {
            String[] parts = currentLine.split("::");
            if (parts.length == 2) {
                list.add(new Flashcard(parts[0], parts[1], mainGame, player));
            }
        }

        reader.close();
        return list;
    }

    /**
     * Checks if a file is a valid flashcard file based on its format.
     * 
     * @param file the file to validate
     * @return true if the file is valid, false otherwise
     */
    public static boolean isValidFlashcardFile(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                String[] parts = currentLine.split("::");

                if (parts.length != 2 || parts[0].trim().isEmpty() || parts[1].trim().isEmpty()) {
                    return false;
                }
            }

            return true; 
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Sets the internal flashcard file reference for saving/loading.
     * 
     * @param file the flashcard file
     */
    public List<Flashcard> getFlashcards() {
        return flashcardSet;
    }

    /**
     * Sets the player associated with flashcard actions.
     * 
     * @param player the player object
     */
    public void setPlayer(GameObject player) {
        this.player = player;
    }
}
